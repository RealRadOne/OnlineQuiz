<!DOCTYPE html>
<html>
<head>
<title>Tie Breaker Round</title>
<style>
body[background] {
    background-repeat: no-repeat;
    background-position: center;
}
</style>
</head>
<body background="mixedbag.jpg">
<?php
$a=$_GET["a"];
$b=$_GET["b"];
$c=$_GET["c"];
$d=$_GET["d"];
?>
<center>
<br><br><br><br>
    <h1>TIE BREAKER</h1>
    <br><br>
    <h1>Mixed Bag</h1>
    <br><br>
    <h3>
    <p>
     12 Questions
     <br><br>
    (2 marks each)
    <br><br>
    </p>
    </h3>
      <form action="q49.php">
      <input type="hidden" name="a" value="<?php echo $a; ?>">
      <input type="hidden" name="b" value="<?php echo $b; ?>">
      <input type="hidden" name="c" value="<?php echo $c; ?>">
      <input type="hidden" name="d" value="<?php echo $d; ?>">
      <button type="submit"><b>Begin Tie Breaker Round</b></button>
      </form>
      <br><br><br><br><br><br><br><br><br><br><br><br>
</center>
</body>
</html>