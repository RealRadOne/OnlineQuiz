<!DOCTYPE html>
<html>
<head>
<title>Round 1</title>
<style>
body[background] {
    background-repeat: no-repeat;
    background-position: center;
}
input[type="submit"] {
  font-weight: bold;
}
</style>
</head>
<body background="sportslaw.png">
<?php
$choice=$_GET["choice"];
$correct=$_GET["correct"];
$a=$_GET["a"];
$b=$_GET["b"];
$c=$_GET["c"];
$d=$_GET["d"];
if(isset($_GET["b1"]) && $choice==$correct){
$a+=2;
}
else if(isset($_GET["b2"]) && $choice==$correct){
$b+=2;
}
else if(isset($_GET["b3"]) && $choice==$correct){
$c+=2;
}
else if(isset($_GET["b4"])&& $choice==$correct){
$d+=2;
}
?>
<center>
<br><br><br><br>
    <h1>Question 18</h1>
    <br><br>
    <h2> This is the second MCQ question. Click on the radio button for selecting an answer. </h2>
    <br>
    <form action="a18.php">
    <h4>
      <input type="radio" name="a2" value="a"> Option A &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
      <input type="radio" name="a2" value="b"> Option B <br><br>
      <input type="radio" name="a2" value="c"> Option C &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
      <input type="radio" name="a2" value="d"> Option D <br>
      <br><br><br><br>
      <input type="submit" name="b1" value="Submit Answer"> &emsp;&emsp;
      <input type="submit" name="b2" value="Pass">
      <input type="hidden" name="a" value="<?php echo $a; ?>">
      <input type="hidden" name="b" value="<?php echo $b; ?>">
      <input type="hidden" name="c" value="<?php echo $c; ?>">
      <input type="hidden" name="d" value="<?php echo $d; ?>">
    </h4>
    </form>
      <br><br><br><br><br><br><br><br><br><br><br><br>
</center>
</body>
</html>