<!DOCTYPE html>
<html>
<head>
<style>
body[background] {
    background-repeat: no-repeat;
    background-position: center;
}
.modal {
    display: none;
    position: fixed;
    z-index: 1;
    padding-top: 100px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgb(0,0,0);
    background-color: rgba(0,0,0,0.4);
}
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 80%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}
@-webkit-keyframes animatetop {
    from {top:-300px; opacity:0} 
    to {top:0; opacity:1}
}
@keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}
.modal-header {
    padding: 2px 16px;
    background-color: lightpink;
    color: black;
}
.modal-footer {
    padding: 2px 16px;
    background-color: lightblue;
    color: black;
}
</style>
</head>
<body background='medialaw.jpg'>
<?php
$choice=$_GET["choice"];
$correct=$_GET["correct"];
$a=$_GET["a"];
$b=$_GET["b"];
$c=$_GET["c"];
$d=$_GET["d"];
if(isset($_GET["b1"]) && $choice==$correct){
$a+=2;
}
else if(isset($_GET["b2"]) && $choice==$correct){
$b+=2;
}
else if(isset($_GET["b3"]) && $choice==$correct){
$c+=2;
}
else if(isset($_GET["b4"])&& $choice==$correct){
$d+=2;
}
?>
<div id="myModal" class="modal">
  <div class="modal-content">
  <center>
    <div class="modal-header">
      <h1>RESULTS</h1>
      <h2>after Round 2</h2>
    </div>
    <div class="modal-footer">
    <br><br>
    <table border="2" cellpadding="10" cellspacing="5">
    <tr>
    <td><b>TEAM NAME</b></td> <td><b>SCORE</b></td>
    </tr>
    <tr>
    <td>TEAM A</td> <td><?php echo $a;?></td>
    </tr>
    <tr>
    <td>TEAM B</td> <td><?php echo $b;?></td>
    </tr>
    <tr>
    <td>TEAM C</td> <td><?php echo $c;?></td>
    </tr>
    <tr>
    <td>TEAM D</td> <td><?php echo $d;?></td>
    </tr>
    </table>
    <br><br>
      <form action="round3.php">      
      <input type="hidden" name="a" value="<?php echo $a; ?>">
      <input type="hidden" name="b" value="<?php echo $b; ?>">
      <input type="hidden" name="c" value="<?php echo $c; ?>">
      <input type="hidden" name="d" value="<?php echo $d; ?>">
      <button type="submit"><b>Proceed to Round 3</b></button>
      </form>
      <br>
    </div>
    </center>
  </div>
</div>
<script>
var modal = document.getElementById('myModal');
modal.style.display = "block";
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</body>
</html>