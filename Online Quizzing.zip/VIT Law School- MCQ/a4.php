<!DOCTYPE html>
<html>
<head>
<title>Round 1</title>
<style>
body[background] {
    background-repeat: no-repeat;
    background-position: center;
}
.rad {
    background-color: lightgreen;
    padding-right: 5px;
    display: inline-block;
    border: 2px solid green;
}
input[type="submit"] {
    font-weight: bold;
}
</style>
</head>
<body background="sportslaw.png">
<?php
if(isset($_GET["b2"])) {
$choice="";
}
else {
$choice=$_GET["a2"];
}
$correct="b";
?>
<center>
<br><br><br><br>
    <h1>Question 4</h1>
    <br><br>
    <h2> This is the first MCQ question. Click on the radio button for selecting an answer. </h2>
    <form action="q5.php">
    <h4>
      <?php if($correct=="a") echo "<div class='rad'>"?>
      <input type="radio" name="a2" value="a" 
      <?php if($choice=="a") echo "checked";?> 
      >Option A <?php if($correct=="a") echo "</div>"?>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
      <?php if($correct=="b") echo "<div class='rad'>"?>
      <input type="radio" name="a2" value="b" 
      <?php if($choice=="b") echo "checked";?> 
      >Option B <?php if($correct=="b") echo "</div>"?><br><br>
      <?php if($correct=="c") echo "<div class='rad'>"?>
      <input type="radio" name="a2" value="c" 
      <?php if($choice=="c") echo "checked";?> 
      >Option C <?php if($correct=="c") echo "</div>"?>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
      <?php if($correct=="d") echo "<div class='rad'>"?>
      <input type="radio" name="a2" value="d" 
      <?php if($choice=="d") echo "checked";?> 
      >Option D <?php if($correct=="d") echo "</div>"?>
      <br><br><br><br>
<?php
if(isset($_GET["b1"])) { ?>
      <input type="submit" name="b1" value="Team A"> &emsp;&emsp;&emsp;&emsp;
      <input type="submit" name="b2" value="Team B"> <br><br>
      <input type="submit" name="b3" value="Team C"> &emsp;&emsp;&emsp;&emsp;
      <input type="submit" name="b4" value="Team D"> <br>

<?php
}
else if(isset($_GET["b2"])) {
  echo "<input type='submit' name='b' value='Next Question'>";
}
$a=$_GET["a"];
$b=$_GET["b"];
$c=$_GET["c"];
$d=$_GET["d"];
?>
    <input type="hidden" name="choice" value="<?php echo $choice; ?>">
    <input type="hidden" name="correct" value="<?php echo $correct; ?>">
    <input type="hidden" name="a" value="<?php echo $a; ?>">
    <input type="hidden" name="b" value="<?php echo $b; ?>">
    <input type="hidden" name="c" value="<?php echo $c; ?>">
    <input type="hidden" name="d" value="<?php echo $d; ?>">
    </h4>
    </form>
      <br><br><br><br><br><br><br><br><br><br><br><br>
</center>
</body>
</html>